export default ({ children }) => {
  return children
}
