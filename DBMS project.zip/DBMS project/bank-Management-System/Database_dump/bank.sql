Create database if not exists bank;
use bank;

CREATE TABLE `BranchTable` (
  `BCode` VARCHAR(15) NOT NULL,
  
 `Name` VARCHAR(120) NOT NULL,

 `Address` VARCHAR(200) NOT NULL,

  PRIMARY KEY (`BCode`));

INSERT INTO `branchtable` (`Name`, `BCode`, `Address`) VALUES
('newjersy', 'SBI234323', 'xyz');
INSERT INTO `branchtable` (`Name`, `BCode`, `Address`) VALUES
('indiatoday', 'SBI234326', 'xyzasdf');


CREATE TABLE `EmployeeTable` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(50) NOT NULL,
  `Branch` VARCHAR(50) NOT NULL,
  `BCode` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`Id`),
  FOREIGN KEY (`BCode`) REFERENCES `BranchTable` (`BCode`)
);
INSERT INTO `employeetable` (`Id`, `Name`, `Branch`) VALUES
(1, 'arun', 'Tilakwadi','SBI234323');




CREATE TABLE `AccountTable` (
  
 `Id` INT NOT NULL AUTO_INCREMENT,

 `Account_Number` VARCHAR(15) NOT NULL,
`Account_Type` VARCHAR(15) NOT NULL,
`BCode` VARCHAR(15) NOT NULL,
 `Name` VARCHAR(50) NOT NULL,

 `Gender` VARCHAR(10) NOT NULL,
 `DOB` Date,

 `Address` VARCHAR(50) NOT NULL,

`Aadhar` VARCHAR(12) NOT NULL,

 `Balance` double NOT NULL,

 PRIMARY KEY (`Id`),
 FOREIGN KEY (`BCode`) REFERENCES `BranchTable` (`BCode`)
 ) ;

 INSERT INTO `accounttable` (`Id`, `Account_Number`, `Account_Type`, `BCode`, `Name`, `Gender`, `DOB`, `Address`, `Aadhar`, `Balance`) VALUES
(1, 'SBI23432310001', 'Savings', 'SBI234323', 'shashank', 'M', '2018-09-06', 'xyz xyz', '234432234', 20500);


CREATE TABLE `TransactionTable` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Date` Date NOT NULL,
  `Account_Num` VARCHAR(15),
  `Transaction_Type` VARCHAR(15),
  `Amount` DOUBLE,
  PRIMARY KEY (`Id`)

);
INSERT INTO `transactiontable` (`Id`, `Date`, `Account_Num`, `Transaction_Type`, `Amount`) VALUES
(1, '2018-09-06', 'SBI23432310001', 'Credit', 21000),
(2, '2018-09-06', 'SBI23432310001', 'Debit', 500);
 

CREATE TABLE `FeedbackTable` ( 
  `feedback_id` INT AUTO_INCREMENT PRIMARY KEY, 
  `Date` DATE NOT NULL,
  `person_name` VARCHAR(200),
  `Account_Num` VARCHAR(15),
  `TransactionId` INT NOT NULL,
  `complaint` VARCHAR(200), 
 
  
  FOREIGN KEY (`TransactionId`) REFERENCES `TransactionTable` (`Id`)

 );

INSERT INTO `FeedbackTable` (`feedback_id`, `Date`, `person_name`, `Account_Num`, `TransactionId`, `complaint`) VALUES
('1','2018-09-06', 'shashank','SBI23432310001', '2', 'bank server down');



