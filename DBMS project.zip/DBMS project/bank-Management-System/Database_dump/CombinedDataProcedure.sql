DELIMITER //

CREATE PROCEDURE GetFeedbackAndTransaction()
BEGIN
    SELECT
        ft.feedback_id,
        ft.Date AS Feedback_Date,
        ft.person_name,
        ft.Account_Num AS Feedback_Account_Num,
        ft.TransactionId,
        ft.complaint,
        tt.Id AS Transaction_Id,
        tt.Date AS Transaction_Date,
        tt.Account_Num AS Transaction_Account_Num,
        tt.Transaction_Type,
        tt.Amount
    FROM
        FeedbackTable ft
    JOIN
        TransactionTable tt ON ft.TransactionId = tt.Id
    WHERE
        ft.TransactionId = inputTransactionId;
END //

DELIMITER ;

CALL GetFeedbackAndTransaction();
