USE bank;
DELIMITER //
CREATE TRIGGER set_default_balance
BEFORE INSERT ON AccountTable
FOR EACH ROW
BEGIN
    -- Check if Balance is NULL or 0, then set a default value (e.g., 0.0)
    IF NEW.Balance IS NULL OR NEW.Balance = '' THEN
        SET NEW.Balance = 2000.0;
    END IF;

    -- Check if Account_Number is NULL, then set a default value (e.g., 'SBI123456765')
    IF NEW.Account_Number IS NULL OR NEW.Account_Number = '' THEN
        SET NEW.Account_Number = 'SBI1236665498';
    END IF;

END;
//
DELIMITER ;
